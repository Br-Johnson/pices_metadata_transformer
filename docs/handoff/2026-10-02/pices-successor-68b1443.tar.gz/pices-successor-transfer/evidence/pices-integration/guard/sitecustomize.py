import json
import sys
from pathlib import Path

EVENTS = Path('/workspace/scratch/pices-integration/guard-events.jsonl')
def guard(event, args):
    blocked = event in {'socket.connect', 'socket.connect_ex', 'socket.getaddrinfo', 'socket.sendto', 'socket.sendmsg'}
    if event == 'subprocess.Popen':
        command = args[1]
        allowed = command == ['git', 'rev-parse', 'HEAD'] or (
            isinstance(command, (list, tuple)) and len(command) >= 3
            and command[0] == sys.executable
            and command[1:3] == ['-m', 'scripts.curation_batches'])
        blocked = not allowed
    if blocked:
        with EVENTS.open('a') as handle:
            handle.write(json.dumps({'event': event, 'blocked': True}) + '\n')
        raise RuntimeError('Offline validation prohibits ' + event)
sys.addaudithook(guard)
