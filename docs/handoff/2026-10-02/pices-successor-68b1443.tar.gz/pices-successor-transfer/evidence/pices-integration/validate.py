import sys, json, hashlib, subprocess, unittest
from pathlib import Path
from datetime import datetime, timezone

root = Path.cwd()
out = Path('/workspace/scratch/pices-integration')
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover('tests'))
assert result.wasSuccessful(), 'Integration suite failed'
from scripts.collection_qa import classify_collection
from scripts.curation_batches import compile_batches, load_manifest
stamp = datetime.now(timezone.utc).isoformat()
args = ('FGDC', out / 'collection', stamp,
        'docs/readiness/2026-10-02/rehosting_authority.json',
        'docs/readiness/2026-10-02/contact_source_interpretation.json',
        'docs/readiness/2026-10-02/exxon_citation_interpretation.json')
fresh = classify_collection(*args)
fresh_bytes = (out / 'collection/classification.json').read_bytes()
resumed = classify_collection(*args)
assert fresh == resumed and fresh_bytes == (out / 'collection/classification.json').read_bytes()
assert fresh['summary']['source_status_counts'] == {'supported': 1328, 'held': 2872, 'failed': 6}, fresh['summary']
assert fresh['summary']['remote_verified'] == fresh['summary']['publication_approved'] == 0
rows = json.loads(Path('/workspace/scratch/pices-startup-verification/original-source-sha256.json').read_text())
assert len(rows) == 4206
for row in rows:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
copies = list((out / 'collection/data/original_fgdc').glob('*.xml'))
for path in copies:
    assert path.read_bytes() == (root / 'FGDC' / path.name).read_bytes()
decisions, audit = compile_batches([load_manifest('docs/readiness/2026-10-02/cloud_exxon_creator_batch.json')], 'FGDC')
for source_id, decision in decisions.items():
    payload = json.loads((out / 'collection/data/zenodo_json' / (source_id + '.json')).read_text())
    assert payload['metadata']['creators'] == decision['metadata']['creators']
    assert payload['metadata']['access_right'] == 'restricted' and payload['metadata']['license'] == ''
    assert payload['artifact_policy']['source_sha256'] == decision['source_sha256']
    assert 'XML authorship is not independently established' in payload['metadata']['notes']
events = out / 'guard-events.jsonl'
assert not events.exists() or not events.read_text(), 'Blocked events were recorded'
receipt = {
    'tested_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'blocked_events': [], 'reviewed_at': stamp,
    'classification_sha256': hashlib.sha256(fresh_bytes).hexdigest(),
    'classification_summary': fresh['summary'], 'fresh_resume_byte_identical': True,
    'originals_unchanged': len(rows), 'copies_identical': len(copies),
    'compiled_creator_members_checked': len(decisions),
    'compiled_membership_sha256': audit['batches'][0]['membership_sha256'],
    'scripts_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(Path('scripts').rglob('*.py'))},
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('INTEGRATION_RECEIPT', json.dumps({key: value for key, value in receipt.items() if key != 'scripts_sha256'}, indent=2))
