# Independent compiler review

Reviewed the complete compiler addition against `35b01a265b86125459e1047b30297a4cbcea5210`, including the transferred WIP repair against `9811a2878f276f798585a16a43db2fdaa894d69e`, and the final reference-schema delta. Frozen reviewed head: `8d2fdeba3368d90128208be4eef5372ca1df3468` (includes `b65b868`). Read repository AGENTS.md, module, tests and docs, plus existing transformer decision application, artifact contracts and content classification. No repository edits or provider operations were made.

**Result: no blocking defect found in this bounded compiler diff.**

Validated by inspection:

- Strict root/batch/selector/correction structures reject unsupported keys and versions, duplicate JSON keys, unsupported selectors, empty corrections and invalid review timestamps. Member IDs and lowercase raw-byte hashes are constrained.
- Selection uses original source XML; explicit selectors reject missing/malformed sources. Whole-cohort exact ID equality plus per-member hashes rejects missing, extra and stale memberships. Symlink source entries fail. Malformed XML exclusions remain inspectable in the audit.
- Field ownership tracks every equal-value contributor. Conflicting writes require explicit supersession of every currently active owner, including across manifests. Disjoint fields compose; artifact policy and content inventory each remain atomic. All reviews and fingerprints survive composition.
- Only the exact artifact hash and filename fields are interpolated. Original XML bytes are never changed. Artifact policy/content declarations must travel together and validate against the existing artifact contract.
- All affected transformations validate before CLI output creation. Existing output files, hardlink targets, source-directory outputs and input-manifest outputs are refused. Exclusive creation prevents accidental overwrites. The documented possibility of a partial output pair on filesystem failure remains; failed invocations must not be consumed.
- Audit hashes cover inventory, manifests, exact memberships, decisions and validated output records. The compiler does not upload, publish, grant rights, remove alias holds or clear access restrictions.

Independent execution: 34 focused tests passed under the supplied socket/subprocess guard, using the main environment venv and the curation worktree. No guard event file was generated. `git diff --check 35b01a2..HEAD` passed. The later `8d2fdeb` delta was inspected explicitly: it only permits the three named policy-reference objects with exact `manifest_path`/SHA-256 syntax, adds a preservation/rejection regression and documents the boundary.

Application boundaries: `compile_batches` is a pure compiler and does not run transformation validation; the CLI adds `validate_outputs`. Neither is a cohort-promotion gate. Reference syntax checks do not read referenced manifests or establish their authority. Actual source-backed creator interpretation, profile pinning, rights authorization, alias/access holds and QA promotion must be enforced and independently reviewed in the separate creator-profile/integration lane. This review does not approve the 821-member correction application, provider compatibility or GitHub automated review. Combined integration testing remains required.

Final addendum: reviewed additional frozen commit `29a996f` against `8d2fdeb`. XML-only rights scope/XPath syntax, existing nullable policy-license fields and explicit blank metadata license preservation are compatible with the existing contracts and do not infer a license. No new blocking finding. Independently reran the expanded guarded suite: **35 tests passed**, with no guard events. This addendum advances the reviewed compiler head to `29a996f`; all application boundaries above continue to apply.

Final test-only addendum: reviewed `29a996f..94a779d3f0b2e7051b95a053676fa440c885f789`. The sole change adds negative subtests for underlying-data rights scope, dataset-level rights XPath and non-string policy license. These correctly exercise existing rejection branches; no implementation changes or blocking findings. Diff whitespace check passed. **Final reviewed compiler tip: `94a779d3f0b2e7051b95a053676fa440c885f789`.**
