"""Independent read-only census of current remaining holds; no policy application."""
import json,pathlib,hashlib,collections,xml.etree.ElementTree as ET
repo=pathlib.Path('/workspace/pices_metadata_transformer');out=pathlib.Path(__file__).parent;rp=pathlib.Path('/workspace/scratch/pices-integration/collection/classification.json');report=json.loads(rp.read_bytes());rows={r['source_id']:r for r in report['records']};groups={k:collections.defaultdict(list) for k in ['access','access_context','creator','residual']};mismatches=[];malformed=[];evidence={}
paths=['./metainfo/metac','./idinfo/accconst','./metainfo/metuc','./idinfo/useconst']
def normalized(nodes):return tuple(' '.join(''.join(n.itertext()).split()) for n in nodes)
for p in sorted((repo/'FGDC').glob('*.xml')):
 sid=p.stem;raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest();r=rows[sid];m={'source_id':sid,'source_sha256':h}
 if h!=r['source_sha256']:mismatches.append(sid)
 try:root=ET.fromstring(raw)
 except ET.ParseError:malformed.append(sid);continue
 if r['source_status']!='held':continue
 fields={x:normalized(root.findall(x)) for x in paths};plain=all(len(root.findall(x))==1 and not root.find(x).attrib and not list(root.find(x)) for x in paths);security=root.find('./metainfo/metsi') is not None;ext=root.find('./metainfo/metextns') is not None;origin=normalized(root.findall('./idinfo/citation/citeinfo/origin'))
 evidence[sid]={'member':m,'fields':fields,'plain_single_fields':plain,'security':security,'extension':ext,'origins':origin,'hold_reasons':r['hold_reasons'],'technical_metadata':r['technical_metadata']}
 groups['residual'][tuple(sorted(r['hold_reasons']))].append(m)
 if 'Metadata access terms need source-backed adjudication' in r['hold_reasons']:
  groups['access'][fields[paths[0]]].append(m);groups['access_context'][tuple(fields[x] for x in paths)+(plain,security,ext)].append(m)
 if 'Creator semantics are ambiguous' in r['hold_reasons']:groups['creator'][origin].append(m)
summary={}
for kind,gg in groups.items():
 result=[]
 for key,mm in sorted(gg.items(),key=lambda x:(-len(x[1]),str(x[0]))):
  holds=collections.Counter(tuple(sorted(rows[m['source_id']]['hold_reasons'])) for m in mm)
  other=lambda rs: [x for x in rs if x not in (['Metadata access terms need source-backed adjudication','Contradictory or unsupported source access constraints require adjudication'] if kind.startswith('access') else ['Creator semantics are ambiguous'])]
  residual=collections.defaultdict(list)
  for m in mm:residual[tuple(sorted(other(rows[m['source_id']]['hold_reasons'])))].append(m)
  result.append({'pattern':key,'count':len(mm),'members':mm,'member_digest':hashlib.sha256(json.dumps(mm,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'no_other_current_holds':len(residual.get((),[])),'residuals':[{'hold_reasons':k,'count':len(v),'members':v} for k,v in sorted(residual.items(),key=lambda x:(-len(x[1]),x[0]))]})
 (out/(kind+'-groups.json')).write_text(json.dumps(result,indent=2)+'\n');summary[kind]=[{k:v for k,v in x.items() if k not in ('members','residuals')} for x in result]
(out/'held-source-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');s={'classification_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'counts':report['summary'],'source_hash_mismatches':mismatches,'malformed':malformed,'groups':summary};(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
for kind in ('access','access_context','creator'):print(kind,json.dumps(summary[kind][:12],indent=2))
