# Independent registration interpretation review

Status: final review bound to frozen commit `74daa5ad530715c94e301935b9dc5f68b9aee7bf`. Clean worktree confirmed and no remaining blocker found in reviewed scope. Review is read-only; no repository edits, pushes, provider calls, or credential work.

## Independently verified source semantics

The profile's 122 exact source-ID/hash members equal the independent full-4,206-source selector audit. Membership digest: `04387b47d838171bf0eb733e043b26982bf33fb0d3e4fc6fec3cefd49b96a206`. Every original has exact paired metadata/dataset access wording `First time users must register to gain database access.`, exact paired use wording `None`, single plain constraint leaves, and no metadata security/extension elements.

All 122 abstract normalized text values and parsed XML-subtree SHA256 values match original source bytes. Existing abstract markup is retained and bound rather than rejected as nonplain text. All abstracts explicitly describe underlying data/database access and registration: 88 direct account/data-acquisition contexts, 32 download contexts, two data database overviews. This source-backed interpretation does not invent a USER_ATTESTED expansion or grant metadata reuse permission.

## Scope and fail-closed checks

- Reference object requires exact keys and the code-pinned manifest SHA256. Rehashing arbitrary members, context, meaning, status or permission flags cannot expand the profile.
- Both source ID and raw SHA256 membership are required; paired constraints, abstract structure/text and absence of additional security/extension fields are rechecked.
- `validate_dataset_access_policy` requires independent valid rehosting authority, restricted unlicensed metadata, original-XML rights scope and source-metadata-date semantics. Simultaneous legacy Contact Source interpretation is rejected.
- `agent_qa.assess_source` and human schema 1/schema 2 `qa_manifest.validate_approval` all call the same policy validator and reread external evidence. Missing/stale references and altered external manifest bytes fail closed.
- No-reference behavior remains conservative. Unrelated Exxon sources remain unchanged. Creator/date/relation/alias gates still execute; the new rule only interprets the audited registration access constraint.
- Collection profile fingerprints include all Python rule bytes and the manifest reference. Cache reuse rechecks current policy and reruns source QA; coherent payload-hash edits cannot license a record. Agent evidence fingerprints include `dataset_access_interpretation.py` and are revalidated.
- Compiler schema accepts only shaped path/SHA256 references in the optional policy field. Compiler acceptance is not semantic approval, source support or publication authorization.

## Actual output comparison

Independently compared baseline and interpreted 122-source preparations under `/workspace/scratch/registration-profile` against original XML and independent census. Baseline: zero supported, 122 held. Interpreted: **78 supported, 44 held**, consisting of 23 ambiguous creators and 21 empty creators. All 122 memberships/hashes match; copied source bytes are unchanged. Full metadata objects—including creators, dates, title/description, attribution notes, restricted access and blank license—are identical before/after. Aside from run timestamps, the policy difference is the added dataset-access interpretation reference. Zero discrepancies found.

Evidence: `/workspace/scratch/pices-registration-output-crosscheck.json`. Source support remains offline classification; publication_approved=false and remote_verified=false.

## Tests and findings

Thirteen new profile tests passed independently, covering source/context mutation, stale/missing references, rehashed arbitrary profiles, absent authority, rights changes, conflicting interpretation, human schema 1/2 approval, agent QA, cached payload mutation and compiler reference schema. Initial review caught an in-progress compiler fixture error, promptly reported; writer corrected the fixture and the complete focused suite passed. No runtime policy defect or remaining blocker was found. Final frozen-diff check and writer full-suite evidence follow below.

## Frozen final evidence

Final frozen diff and documentation match the reviewed implementation; whitespace check passed. Independently reran 13 focused profile tests. Inspected writer's full blocked-socket log: 196 tests passed, zero network attempts. Committed residual memberships exactly match all 44 held source IDs/hashes and reasons. No remaining in-scope defect found. This local review does not substitute for GitHub automated review, live duplicate/provider verification, credential availability, or release approval. PR8 stable branch was not moved or pushed by this lane.

## Whole-corpus independent addendum

Inspected the saved whole-corpus receipt and actual outputs without rerunning classification. Independently checked all 45 current Python rule files against both receipt SHA256 values and frozen commit `74daa5ad530715c94e301935b9dc5f68b9aee7bf`. Recomputed the collection profile hash from those scripts and all four actual manifest references; it matches `8b025cbb6cba2fd66b9fea74199341b3645c9aa7d7c645561602602d78b1c648`. Every referenced manifest digest matches its current bytes (relative references resolved in the tested repository).

Final classification digest independently matches receipt: `493fb16aa56084d789a15ce0f7294e5aab2206c0ebdc993c13e088d50398e1d1`. Independently counted 1,406 supported, 2,794 held and six failed. Exactly 78 status changes are held-to-supported, with source IDs identical to the independently reviewed 122-member cohort's 78 promotions; every other status is unchanged. Rechecked 4,206 original hashes, 4,200 identical source copies and 4,194 complete unchanged metadata objects versus saved main baseline. Zero mismatches found.

The receipt and saved execution log attest fresh/resume byte equality. This review independently verifies the final saved classification's bytes and digest; it does not claim an independent pre-resume snapshot comparison where no separate saved snapshot was supplied. Full-corpus validation is still source-only, with publication_approved=0 and remote_verified=0. No classifier/provider rerun or PR8 changes occurred in this addendum.

Independent machine-readable evidence: `/workspace/scratch/pices-registration-whole-independent.json`; reproducible read-only check: `/workspace/scratch/pices-registration-whole-independent.py`. No new blocker found.
