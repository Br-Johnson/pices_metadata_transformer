# Independent creator profile review

Status: final review of frozen commit `724a939335617bafc44e8fa3ace49c1d56651d2d`. No remaining blockers found in reviewed scope. Clean worktree confirmed; reviewed code is identical to frozen commit.

Read-only review of `/workspace/pices-creator-profile` against independently audited source census. No source or implementation edits and no provider calls.

## Finding repaired and verified

Human/schema-1 QA approval through `qa_manifest.validate_approval` did not revalidate `artifact_policy.creator_interpretation`, although authority and access interpretation references are revalidated there. External manifest content could change/disappear while its reference and policy hash stay unchanged. A scratch proof coherently prepared a source/payload/artifact contract with an invalid missing creator reference and received human QA approval. Probe: `/workspace/scratch/pices-creator-human-probe.py`. This is an all-route policy-validation gap; agent evidence calls source QA again and was already protected.

Precision: the artifact contract DOES hash the policy object. In-payload reference edits are therefore caught by artifact staleness checks; the missing check concerns actual external referenced content and invalid coherent references.

Writer added creator-reference revalidation and exact full creator equality in the all-route approval validator. The same scratch probe now rejects the invalid reference. Both human schema 1 and human schema 2 regression cases pass.

## Verified positive constraints

- Pinned manifest SHA256 `ee49147aec99d83cf54cb7fa4e59f7e50229967af0f08f5408e97144367e99e5` matches validator constant.
- All 821 manifest members equal independent census members in exact source-ID/hash order, digest `c0c7562f0dc229b190596620be5c584e9ec1a6ec00ef20e5cf7b1f793710e84e`.
- Full creator objects match independently audited primary-origin grammar: Council organization, Bodkin/James with exact USGS/location affiliation, Dean/Thomas A. with exact Coastal Resources/location affiliation. No contact-derived middle initial or invented article/XML authorship.
- Validator requires exact reference keys, pinned manifest bytes, exact source-ID/hash membership and one plain exact primary origin leaf. Source outside cohort, changed hash, changed/nested/repeated/attributed origins fail.
- Agent source QA compares full ordered creator dictionaries, including affiliations and any unexpected identifiers. Default ambiguity checks remain unchanged when no reference is present.
- New path precedes but does not skip existing rights, date, access, relation checks. Collection's alias adjudication pass is unchanged.
- Collection profile hashes all script bytes and creator reference; cached policy equality guards profile removal. Agent rule fingerprint adds the new validator; evidence revalidation reruns source QA.
- All ten final creator-profile tests passed independently; `git diff --check` passed.

## Test-quality observation

The initial cache-specific test calls a helper using a fresh `datetime.now()` review time on each run. Because collection cache reuse requires identical `reviewed_at`, that test initially covered regeneration rather than the intended cached payload branch. Writer repaired this test and added a coherent editable cache/payload hash attack. Both pass; the tampered affiliation is held by full-object creator checking.

Final frozen-commit verification reran the scratch failure probe: invalid manifest reference rejected. Final commit diff whitespace check passed.

## Migrated compiler and actual output cross-check

Independently read the migrated `cloud_exxon_creator_batch.json`, compiled `decisions.json`/`audit.json`, and all 821 prepared JSON outputs in `/workspace/scratch/exxon-profile/821/output`. The migrated batch supplies required schema envelope, version, selector normalization, updated explicit reviewer/rationale, and preserves historical candidate evidence. Every member/hash equals the independently enumerated originals. All 821 compiler decision creator objects equal the profile manifest and every prepared full creator object. Audit overlaps are empty and publication_authorized=false. This comparison does not claim the raw legacy compiler CLI transformation/schema route was run.

Prepared profile evidence has 414 supported and 407 held, all 821 technically passing. Holds are exactly 406 exact-copy members and FGDC-1994 with both collection access and source-QA access diagnostics. Source hashes, original metadata rights/access/date fields remain identical to the baseline. All 821 payloads retain restricted access and no license grant. Independent cross-check found zero mismatches; evidence saved at `/workspace/scratch/pices-creator-cohort-crosscheck.json`.

## Final verification scope

Writer final validation log reports 170 passing offline tests with zero network attempts. Independent review reran ten focused profile tests and the concrete human-QA bypass probe, inspected final clean frozen diff and documentation, and cross-checked all 821 actual output objects/members/source fields against independent census and compiled decisions. No remaining blocker was found. This is local independent code/evidence review, not GitHub automated Codex review, provider verification, publication authorization, or a merge approval. No provider writes occurred in this review.
