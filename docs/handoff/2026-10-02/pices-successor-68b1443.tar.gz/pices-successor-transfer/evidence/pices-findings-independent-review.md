# Independent findings diff review

Reviewed commit `99a769d87ae601123717a952035e08f0315219ab` against public base `35b01a265b86125459e1047b30297a4cbcea5210` in `/workspace/pices-findings`. Read AGENTS.md and all six changed files, plus the shared upload service, path configuration, source-resolution callers and batch uploader selection path. No repository edits or provider calls were made.

**Result: no blocking findings in this bounded diff.**

The source resolver now selects repository-root `FGDC/<id>.xml` first and requires every present candidate to contain identical bytes. Divergent, unreadable, directory and dangling-link candidates fail before preparation reaches a provider; fallback and identical aliases remain compatible. Raw hash calculation continues to read unchanged original bytes. The implementation neither rewrites originals nor infers rights.

The compatibility uploader now intersects the caller's ordered list with pending eligibility before applying its limit. A completed prefix therefore does not consume a batch slot. Per-invocation result lists and counters reset together, while the authoritative environment registry remains owned by the unchanged shared upload service. Its source/payload binding, reconciliation, retry-ID, artifact and duplicate-inventory checks remain in place.

Independent execution: all 13 focused source-resolution and batch-selection regression tests passed using `/workspace/pices_metadata_transformer/venv/bin/python -m unittest tests.test_fgdc_source_resolution tests.test_upload_batch_selection -v`. These use temporary fixtures and mock clients. `git diff --check 35b01a2..99a769d` passed. Separately inspected the implementation lane's full-suite evidence: 160 passing tests, `BLOCKED_EVENTS []`, and 40 allowed local revision lookups; inspected its source-preservation evidence for 4,206 unchanged originals and ten identical sample copies. The full suite/source census were not independently repeated by this reviewer.

Limits: source discovery remains relative to execution cwd, so run from repository root. Sources are not locked against concurrent filesystem writers, which must remain stopped. Pending selection validates the complete prepared directory before restricting the caller subset, intentionally failing closed on unrelated invalid inputs. Zero-limit behavior remains unlimited as before. These pre-existing constraints are documented in the diff and are not new defects introduced here. No curation compiler code, correction cohort, live provider behavior or GitHub automated review is approved by this review.
